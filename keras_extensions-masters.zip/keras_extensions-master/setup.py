from setuptools import setup
from setuptools import find_packages


setup(name='keras_extensions',
      version='0.1',
      description='Some Keras extensions',
      author='Merlijn Blaauw',
      author_email='',
      url='https://github.com/wuaalb/keras_extensions',
      download_url='',
      license='MIT',
      install_requires=[],
      packages=find_packages())